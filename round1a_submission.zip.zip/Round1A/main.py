import fitz  # PyMuPDF
import os
import json

def classify_heading(text, font_size, font_flags):
    if font_flags & 2:
        if font_size >= 17:
            return "H1"
        elif font_size >= 14:
            return "H2"
        elif font_size >= 11.5:
            return "H3"
    return None

def extract_outline(pdf_path):
    doc = fitz.open(pdf_path)
    headings = []
    title_candidates = []

    for page_num, page in enumerate(doc, start=1):
        blocks = page.get_text("dict")["blocks"]
        for b in blocks:
            for line in b.get("lines", []):
                for span in line["spans"]:
                    text = span["text"].strip()
                    if not text or len(text) < 2:
                        continue
                    level = classify_heading(text, span["size"], span["flags"])
                    if level:
                        headings.append({
                            "level": level,
                            "text": text,
                            "page": page_num
                        })
                    if span["size"] > 20:
                        title_candidates.append(text)

    title = max(set(title_candidates), key=title_candidates.count) if title_candidates else "Untitled"
    return {"title": title, "outline": headings}

def main():
    input_dir = "/app/input"
    output_dir = "/app/output"
    os.makedirs(output_dir, exist_ok=True)

    for filename in os.listdir(input_dir):
        if filename.lower().endswith(".pdf"):
            path = os.path.join(input_dir, filename)
            result = extract_outline(path)
            output_filename = os.path.splitext(filename)[0] + ".json"
            with open(os.path.join(output_dir, output_filename), "w") as f:
                json.dump(result, f, indent=2)

if __name__ == "__main__":
    main()
