# Adobe Hackathon Round 1A

Extracts headings (H1, H2, H3) and document title from PDFs.

## Build
docker build --platform linux/amd64 -t pdf-outline-extractor .

## Run
docker run --rm -v $(pwd)/input:/app/input -v $(pwd)/output:/app/output --network none pdf-outline-extractor
